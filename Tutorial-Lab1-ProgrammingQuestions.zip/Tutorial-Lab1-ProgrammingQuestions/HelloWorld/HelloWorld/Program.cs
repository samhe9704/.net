﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
Write a program to print Hello World 
in the console
 */
namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            // Write the code to print Hello World


            // Write the code to accept a single key press from the user

        }
    }
}

/*
Test case:

Expected Output:
Hello World

*/
